import { Component, ElementRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  @ViewChild('f', {static:false}) formRef : NgForm;
  defaultValue = 'teacher';
  answer = '';

  suggestUserName(){
    const suggestedName = 'superUser';
  }

  // onSubmit(form:NgForm){
  //   console.log(form);
  // }

  onSubmit(){
    console.log(this.formRef) //we can refer to our object which is created by angular by any of the process mentioned above. 
  }
}
